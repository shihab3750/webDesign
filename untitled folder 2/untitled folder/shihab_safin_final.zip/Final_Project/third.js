function play() {
  var audio = document.getElementById("audio");
  audio.play();
}
